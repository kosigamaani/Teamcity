import spacy
from nltk.corpus import brown
import re

# nlp = spacy.load('en_core_web_md')

sentences = brown.sents(categories=['news'])

corpus = sentences[:30]

a_train = corpus[:20]
print('size : ', len(a_train))
b_train = corpus[10:]
print('size : ', len(b_train))

def validate_word(word):
    xx = re.sub('([a-zA-z])\'([a-zA-Z]+)', lambda x: x.group(0).replace('\'', ''), word)
    xx = re.sub('([a-zA-z])`([a-zA-Z]+)', lambda x: x.group(0).replace('`', ''), xx)
    xx = re.sub('([a-zA-z])\'([a-zA-Z]+)', lambda x: x.group(0).replace('.', ''), xx)
    xx = re.sub('([a-zA-z])\'([a-zA-Z]+)', lambda x: x.group(0).replace(',', ''), xx)
    xx = re.sub('([a-zA-z])\'([a-zA-Z]+)', lambda x: x.group(0).replace('\'', ''), xx)
    xx = re.sub('([a-zA-z])\'([a-zA-Z]+)', lambda x: x.group(0).replace('\'', ''), xx)

    tt = re.match('[^a-zA-Z]', xx)
    if tt is not None:
        xx = ''

    #print('result : ', xx)
    return xx

#print(a_train)
first = ''
second = ''

for sent in a_train:
    for word in sent:
        #print('processing : ', word)
        first = first + validate_word(word) + ' '

for sent in b_train:
    for word in sent:
        #print('processing : ', word)
        second = second + validate_word(word) + ' '

print(first)
print(second)

with open('first', 'w') as f_first:
    f_first.write(first)
with open('second', 'w') as f_second:
    f_second.write(second)

# tokens = nlp(u'dog cat banana afskfsd')

#for token in tokens:
#    print(token.text, token.has_vector, token.vector_norm, token.is_oov)