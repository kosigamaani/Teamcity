import numpy as np
from sklearn.decomposition import PCA
from matplotlib import pyplot as plt

def generate(vocab_file, vectors_file):

    with open(vocab_file, 'r') as f:
        words = [x.rstrip().split(' ')[0] for x in f.readlines()]
    with open(vectors_file, 'r') as f:
        vectors = {}
        for line in f:
            vals = line.rstrip().split(' ')
            vectors[vals[0]] = [float(x) for x in vals[1:]]

    vocab_size = len(words)
    vocab = {w: idx for idx, w in enumerate(words)}
    ivocab = {idx: w for idx, w in enumerate(words)}

    vector_dim = len(vectors[ivocab[0]])
    W = np.zeros((vocab_size, vector_dim))
    for word, v in vectors.items():
        if word == '<unk>':
            continue
        W[vocab[word], :] = v

    # normalize each word vector to unit variance
    W_norm = np.zeros(W.shape)
    d = (np.sum(W ** 2, 1) ** (0.5))
    W_norm = (W.T / d).T
    return (W_norm, vocab, ivocab)


def distance(W, vocab, ivocab, input_term):
    for idx, term in enumerate(input_term.split(' ')):
        if term in vocab:
            print('Word: %s  Position in vocabulary: %i' % (term, vocab[term]))
            if idx == 0:
                vec_result = np.copy(W[vocab[term], :])
            else:
                vec_result += W[vocab[term], :]
        else:
            print('Word: %s  Out of dictionary!\n' % term)
            return

    vec_norm = np.zeros(vec_result.shape)
    d = (np.sum(vec_result ** 2, ) ** (0.5))
    vec_norm = (vec_result.T / d).T

    dist = np.dot(W, vec_norm.T)

    for term in input_term.split(' '):
        index = vocab[term]
        dist[index] = -np.Inf

    a = np.argsort(-dist)[:N]

    print("\n                               Word       Cosine distance\n")
    print("---------------------------------------------------------\n")
    for x in a:
        print("%35s\t\t%f\n" % (ivocab[x], dist[x]))


if __name__ == "__main__":
    first_vec = []
    sec_vec = []
    combined_vec= []
    N = 100;  # number of closest words that will be shown
    W_first, vocab_first, ivocab_first = generate('/home/kosi/PycharmProjects/Similarity/first_glove/vocab.txt', '/home/kosi/PycharmProjects/Similarity/first_glove/vectors.txt')
    W_second, vocab_second, ivocab_second = generate('/home/kosi/PycharmProjects/Similarity/second_glove/vocab.txt',
                                '/home/kosi/PycharmProjects/Similarity/second_glove/vectors.txt')
    W_combined, vocab_combined, ivocab_combined = generate('/home/kosi/PycharmProjects/Similarity/combined/vocab.txt',
                                                  '/home/kosi/PycharmProjects/Similarity/combined/vectors.txt')


    for word, idx in vocab_first.items():
        first_vec.append(W_first[vocab_first[word], :])

    for word, idx in vocab_second.items():
        sec_vec.append(W_second[vocab_second[word], :])

    for word, idx in vocab_combined.items():
        combined_vec.append(W_combined[vocab_combined[word], :])

    # print(first_vec)

    pca = PCA(n_components=2)
    result_first = pca.fit_transform(first_vec)

    print(len(vocab_first))
    print('word in first corpus : ', vocab_first.keys())
    print('word in second corpus : ', vocab_second.keys())
    print('word in combined corpus : ', vocab_combined.keys())
    print(len(vocab_second))
    print(len(vocab_combined))

    plt.scatter(result_first[:, 0], result_first[:, 1])
    for i, word in enumerate(list(vocab_first.keys())):
        plt.annotate(word, xy=(result_first[i, 0], result_first[i, 1]))
    plt.show()

    pca = PCA(n_components=2)
    result_second = pca.fit_transform(sec_vec)

    plt.scatter(result_second[:, 0], result_second[:, 1])
    for i, word in enumerate(list(vocab_second.keys())):
        plt.annotate(word, xy=(result_second[i, 0], result_second[i, 1]))
    plt.show()

    pca = PCA(n_components=2)
    result_combined = pca.fit_transform(combined_vec)

    plt.scatter(result_combined[:, 0], result_combined[:, 1])
    for i, word in enumerate(list(vocab_combined.keys())):
        plt.annotate(word, xy=(result_combined[i, 0], result_combined[i, 1]))
    plt.show()
