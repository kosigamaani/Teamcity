from ext.loader import corpusloader
from ext.spacymodel import spacymodel

class dependencytree:

    def __init__(self, model):
        self.__model = model

    def getdependency(self, sentence):
        dependency_tree = self.__model(sentence)
        tokens = sentence
        for token in dependency_tree:
            tokens = tokens + ' ' + self.getrelation(sentence.split(), token.text, token.head.text, token.dep_)
        return tokens

    def getrelation(self, sentence, text, headtext, dep):
        text_idx = sentence.index(text)
        headtext_idx = sentence.index(headtext)
        if text_idx < headtext_idx:
            return str(text) + ':' + str(dep) + '_' + str(headtext)
        else:
            return str(text) + ':' + str(dep) + '-1_' + str(headtext)


    def getdependencycorpus(self):
        return self.__dependencycorpus
